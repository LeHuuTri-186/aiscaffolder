package com.example.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class testApplicationTests {
    @Test
    void contextLoads() {
    }
}
