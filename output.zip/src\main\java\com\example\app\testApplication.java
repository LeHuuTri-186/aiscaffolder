package com.example.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class testApplication {
    public static void main(String[] args) {
        SpringApplication.run(testApplication.class, args);
    }
}
